﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace _7MinuteWorkoutApp
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundle/app").Include("~/app/js/app.js"));

            bundles.Add(new ScriptBundle("~/bundle/7MinWorkout").IncludeDirectory("~/app/js/7MinWorkout/", "*.js"));

            //BundleTable.EnableOptimizations = true;
        }
    }
}