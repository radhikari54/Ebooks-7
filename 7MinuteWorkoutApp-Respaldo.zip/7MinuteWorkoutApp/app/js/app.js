﻿/// <reference path="C:\Users\vn00m8d\Documents\Visual Studio 2015\Projects\AngularJSMaintainingWebAplications\7MinuteWorkoutApp\Scripts/angular.js" />
angular.module('app', ['7MinWorkout', 'ngRoute'])
.config(function ($routeProvider, $sceDelegateProvider) {

    /**
     * Config Url Route
     */
    var _urlPartials = '/app/partials/';

    $routeProvider.when('/start', {
        templateUrl: _urlPartials + 'start.html'
    });

    $routeProvider.when('/workout', {
        templateUrl: _urlPartials + 'workout.html',
        controller: 'WorkoutController'
    });

    $routeProvider.when('/finish', {
        templateUrl: _urlPartials + 'finish.html'
    });

    $routeProvider.otherwise({
        redirectTo: '/start'
    });

    /**
     * Allow same origin resource loads
     */
    $sceDelegateProvider.resourceUrlWhitelist([
        'self', 'http://*.youtube.com/**'
    ]);

});